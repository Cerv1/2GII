var searchData=
[
  ['setarrest',['setArrest',['../classcrimen.html#ae08b85470038469179a01ba753b7641a',1,'crimen']]],
  ['setcasenumber',['setCaseNumber',['../classcrimen.html#a98ee8c42a0ec09c704c5f17e812a6bd5',1,'crimen']]],
  ['setdate',['setDate',['../classcrimen.html#ac308c139bb8b599a7badbecd91bfbc5a',1,'crimen']]],
  ['setdescription',['setDescription',['../classcrimen.html#aa2f141046bf44d87e5bc25ae197dcbd0',1,'crimen']]],
  ['setdomestic',['setDomestic',['../classcrimen.html#a3ec14cf4bb0464350d8efd98d2679d41',1,'crimen']]],
  ['setid',['setID',['../classcrimen.html#a2675734f5049f41b5fb5dbc4778df7f8',1,'crimen']]],
  ['setiucr',['setIUCR',['../classcrimen.html#a1f64e937436244d47af1f92cb63c7254',1,'crimen']]],
  ['size',['size',['../classconjunto.html#a52ce2f5a076772be81f7d9bf0c22a558',1,'conjunto']]],
  ['size_5ftype',['size_type',['../classconjunto.html#a855a5893bb0f5a851ab2dbf2b8aa6cc7',1,'conjunto']]]
];
